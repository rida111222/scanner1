/**
* Sample React Native App
* https://github.com/facebook/react-native
*
* @format
* @flow strict-local
*/

import React,{Component} from 'react';
import {
SafeAreaView,
StyleSheet,
ScrollView,
View,
Text,
StatusBar,
TextInput,
} from 'react-native';

import {
Header,
LearnMoreLinks,
Colors,
DebugInstructions,
ReloadInstructions,
} from 'react-native/Libraries/NewAppScreen';
import Mytextinput from './components/Mytextinput';
import Mytext from './components/Mytext';
import Mybutton from './components/Mybutton';

import Realm from 'realm';

let realm;

import QRCodeScanner from 'react-native-qrcode-scanner';


 class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      user_scan: '',
      
    };
    realm = new Realm({ path: 'UserDatabase.realm' });
  }
  scan_user = ()=>{
    var that = this
    const {user_scan}=this.state;
    if(user_scan){realm.write(()=>{
      
      var ID =
      realm.objects('user_details').sorted('user_id', true).length > 0
        ? realm.objects('user_details').sorted('user_id', true)[0]
            .user_id + 1
        : 1;
        realm.create('user_details',{
          user_id:ID,
          user_scan:that.state.qr,
        });
        Alert.alert(
          'Success',
          'You are scan successfully',
          [
            {
              text: 'Ok',
              onPress: () => that.props.navigation.navigate('HomeScreen'),
            },
          ],
          { cancelable: false }
        );
      });
    } else {
      alert('search by scan');
    }
  };
    
  
   state={
     qr:""
   }
   onRead=e =>{
     this.setState({qr:e.data})
   }
  render() {
    return (
      <>
<StatusBar barStyle="dark-content" />
<SafeAreaView>
<ScrollView
contentInsetAdjustmentBehavior="automatic"
style={styles.scrollView}>

<QRCodeScanner


onRead={this.onRead}
/>

{global.HermesInternal == null ? null : (
<View style={styles.engine}>
<Text style={styles.footer}>Engine: Hermes</Text>
</View>
)}
<View style={styles.body}>
<View style={styles.sectionContainer}>
<Mytext style={styles.sectionTitle} 
>{this.state.qr}</Mytext>
<Mybutton
              title="Submit"
              customClick={this.scan_user.bind(this)}
            />

</View>



</View>
</ScrollView>
</SafeAreaView>
</>
);
};
    
  
}




const styles = StyleSheet.create({
  
scrollView: {
backgroundColor: Colors.lighter,
},
engine: {
position: 'absolute',
right: 0,
},
body: {
backgroundColor: Colors.white,
},
sectionContainer: {
marginTop: 32,
paddingHorizontal: 24,
},
sectionTitle: {
fontSize: 24,
fontWeight: '600',
color: Colors.black,
},
sectionDescription: {
marginTop: 8,
fontSize: 18,
fontWeight: '400',
color: Colors.dark,
},
highlight: {
fontWeight: '700',
},
footer: {
color: Colors.dark,
fontSize: 12,
fontWeight: '600',
padding: 4,
paddingRight: 12,
textAlign: 'right',
},
});
